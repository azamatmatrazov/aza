<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>KARSU</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Navbar Start -->
    <div class="container-fluid position-relative nav-bar p-0">
        <div class="container-lg position-relative p-0 px-lg-3" style="z-index: 9;">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0 pl-3 pl-lg-5">
                <a href="" class="navbar-brand">
                    <h1 class="m-0 text-secondary"><span class="text-primary">KAR</span>SU</h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
                    <div class="navbar-nav ml-auto py-0">
                        <a href="#home" class="nav-item nav-link active">BOSH SAHIFA</a>
                        <a href="#about" class="nav-item nav-link">BIZ HAQIMIZDA</a>
                        <a href="#news" class="nav-item nav-link">YANGILIKLAR</a>
                        <a href="#contact" class="nav-item nav-link">BOG'LANISH</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Carousel Start -->
    <section class="home" id="home">
        <div class="container-fluid p-0">
            <div id="header-carousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img class="w-100" src="images/karsu2.png" alt="Image">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <div class="p-3" style="max-width: 900px;">
                                <h4 class="text-white text-uppercase mb-md-3">BERDAQ NOMIDAGI QORAQALPOQ DAVLAT UNIVERSITETI</h4>
                                <h1 class="display-3 text-white mb-md-4">KARAKALPAK STATE UNIVERCITY</h1>
                                <a href="https://karsu.uz/uz/" class="btn btn-primary py-md-3 px-md-5 mt-2">Ko'proq</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item active">
                        <img class="w-100" src="images/karsu2.png" alt="Image">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <div class="p-3" style="max-width: 900px;">
                                <h4 class="text-white text-uppercase mb-md-3">BERDAQ NOMIDAGI QORAQALPOQ DAVLAT UNIVERSITETI</h4>
                                <h1 class="display-3 text-white mb-md-4">KARAKALPAK STATE UNIVERCITY</h1>
                                <a href="https://karsu.uz/uz/" class="btn btn-primary py-md-3 px-md-5 mt-2">Ko'proq</a>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                    <div class="btn btn-secondary" style="width: 45px; height: 45px;">
                        <span class="carousel-control-prev-icon mb-n2"></span>
                    </div>
                </a>
                <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                    <div class="btn btn-secondary" style="width: 45px; height: 45px;">
                        <span class="carousel-control-next-icon mb-n2"></span>
                    </div>
                </a>
            </div>
        </div>
    </section>
    <!-- Carousel End -->

    <!-- Contact Info Start -->
    <div class="container-fluid contact-info mt-5 mb-4">
            <div class="container" style="padding: 0 30px;">
                <div class="row">
                    <div class="col-md-4 d-flex align-items-center justify-content-center bg-secondary mb-4 mb-lg-0" style="height: 100px;">
                        <div class="d-inline-flex">
                            <i class="fa fa-2x fa-map-marker-alt text-white m-0 mr-3"></i>
                            <div class="d-flex flex-column">
                                <h5 class="text-white font-weight-medium">Bizning manzil</h5>
                                <p class="m-0 text-white">Allayar Dosnazarov kóchasi, Nukus, Karakalpakstan</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 d-flex align-items-center justify-content-center bg-primary mb-4 mb-lg-0" style="height: 100px;">
                        <div class="d-inline-flex text-left">
                            <i class="fa fa-2x fa-envelope text-white m-0 mr-3"></i>
                            <div class="d-flex flex-column">
                                <h5 class="text-white font-weight-medium">Bizning elektron pochta
                                </h5>
                                <p class="m-0 text-white">student.karsu.uz</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 d-flex align-items-center justify-content-center bg-secondary mb-4 mb-lg-0" style="height: 100px;">
                        <div class="d-inline-flex text-left">
                            <i class="fa fa-2x fa-phone-alt text-white m-0 mr-3"></i>
                            <div class="d-flex flex-column">
                                <h5 class="text-white font-weight-medium">Bizga qo'ng'iroq qiling
                                </h5>
                                <p class="m-0 text-white">+61-223-58-31</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <!-- Contact Info End -->

    <!-- About Start -->
    <section class="about" id="about">
        <div class="container-fluid py-5">
            <div class="container pt-0 pt-lg-4">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <img class="img-fluid" src="images/karsu.png" alt="" width="600">
                        <img class="img-fluid" src="images/karsu.png" alt="" width="600">
                        <img class="img-fluid" src="images/karsu.png" alt="" width="600">
                    </div>
                    <div class="col-lg-7 mt-5 mt-lg-0 pl-lg-5">
                        <h6 class="text-secondary text-uppercase font-weight-medium mb-3">BIZ HAQIMIZDA BILING
                        </h6>
                        <h1 class="mb-4">Berdaq nomidagi Qoraqalpoq Davlat Universiteti</h1>
                        <p class="mb-2">
                            Qoraqalpoq davlat universiteti, Berdaq nomidagi Qoraqalpoq davlat universiteti — Qoraqalpogʻistondagi eng yirik oliy oʻquv yurti. Ilmiy va pedagog kalrlar tayyorlaydi. 1976-yil Nukus shahrida Qoraqalpoq pedagogika instituti (1934-yil asos solingan) negizida tashkil etilgan. 1992-yil 26 yanvarda Berdaq nomi berilgan. Universitetda 16 f-g (matematika, fizika, kimyo, iqtisodiyot, moliya, xorijiy tillar. muhandislik-qurilish, yurilik, tabiatshunoslik, musiqa va jismoniy tarbiya. tarix. filol., magistratura, sirtqi tabi-iy-iqtisod, sirtqi gumanitar, maxsus sirtqi) va bir boʻlim (jurialistika), 49 kafelra. 30 lan ortiq oʻquv va ilmiy laboratoriya bor. Universitetla pi-leokonferensiya oʻtkazishga moʻljallangan "Lektor" tizimi oʻrnatilgan. Shuning dek oʻquv. ilmiy. oʻqitish jarayonini texnik taʼminlash, iqtidorli talabalar bilan ishlash, xalqaro aloqalar, marketing xizmati, monitoring boʻlimlari, malaka oshirish va kadrlarni qayta tayyorlash, oʻquv-metodik, test, ilgʻor pedagogik texnologiyalar, axborot informaiion texnologiyalar va masofadan oʻqitish. mintaqaviy til oʻrganish, maʼnaviyat va maʼrifat, Oʻzbekistonda demokratik jamiyat qurish nazariyasi va amaliyoti markazlari, bahs-munozara klubi faoliyat kursatadi. Universitetda sanatoriy-profilaktoriy, "Umid" sport sogʻlomlashtirish orom-gohi, oʻquv-amaliyot bazasi, 26 kompyuter sinfi, Berdaq milliy muzeyi, arxeologiya, botanika va zool. muzeylari, madaniyat saroyi, tennis korti. sport majmuasi. amfiteatr, "Xurlimon" ansambli, teatr-studiya. biznes maktabi, 3 akademik lipey, yuridik klinika mavjud. Asosiy kutubxonasida 470 mingdan ziyod asar saqlanadi. Universitet 36 taʼlim yoʻnalishi boʻyicha bakalavrlar. 26 ixtisoslik boʻyicha magistrlar tayyorlaydi. Universitetda 8 mutaxas-sislikboʻyicha aspirantura (1978-yil tashkil etilgan), 2 mutaxassislik boʻyicha doktorantura (1993-yil tashkil etilgan) faoliyat koʻrsatadi. 2004/2005 oʻquv yili universitetda 6875 talaba taʼlim oldi, 462 oʻqituvchi va ilmiy xodim, jumladan Oʻzbekiston Fanlar akademiyasining 3 akad., 22 fan doktori va professor, 163 fan nomzodi va dotsent ishladi. 2000—2004-yillar chet el grantlari asosida 147 ming AQSH dollari miqyaorida ilmiy tadqiqotlar ishlari bajarildi. Universitet bir qancha xorijiy davlatlarning nufuzli universitet va institutlari hamda xalqaro tashkilotlar bilan hamkorlik qiladi. Universitet faoliyati Ch.A.Abdirov, M.K.Nur-muhamedov, K. M. Mambstov. S.K.Kamolov, Q.Oʻteniyozov, J. B. Bozorboyev. A.D .Davletov. T.B.Yeshchanov, H. Hamidov. A.Baxiyev. T. Izimbetov. X. Bobojonov, A.Bekbasov. J. Matmuratov, J.Qutlimuratov. A.Otarov, L.B.Xvan, Yu.Paxratlinov, Q.A. Ismoilov, N.U. Uteuliyev. B.J.Matmuratov. K.Zaretdinov. Ye.Bijanov. S. Qosbergenov, Ye.D. Qoʻtiboyeva va boshqa profoʻqituvchilar nomi bilan bogliq. Universitet tashkil topgantan beri 2005-yilgacha 20 mingdan ortiq mutaxassis tayyorladi.
                            Universitetda "Qoraqalpoq universiteti" gaz. chiqali. Universitet uzining kichik bos-maxonasiga ega boʻlib. unda professoroʻqituvchilarning ilmiy asar va oʻquv metodik adabiyotlari chop etiladi.
                        <div class="row">
                            <div class="col-sm-6 pt-3">
                                <div class="d-flex align-items-center">
                                    <i class="fa fa-check text-primary mr-2"></i>
                                    <p class="text-secondary font-weight-medium m-0">Qoraqalpogʻistondagi eng yirik olin oʻquv yurti</p>
                                </div>
                            </div>
                            <div class="col-sm-6 pt-3">
                                <div class="d-flex align-items-center">
                                    <i class="fa fa-check text-primary mr-2"></i>
                                    <p class="text-secondary font-weight-medium m-0">Universitet 36 taʼlim yoʻnalishi boʻyicha bakalavrlar</p>
                                </div>
                            </div>
                            <div class="col-sm-6 pt-3">
                                <div class="d-flex align-items-center">
                                    <i class="fa fa-check text-primary mr-2"></i>
                                    <p class="text-secondary font-weight-medium m-0">26 ixtisoslik boʻyicha magistrlar</p>
                                </div>
                            </div>
                            <div class="col-sm-6 pt-3">
                                <div class="d-flex align-items-center">
                                    <i class="fa fa-check text-primary mr-2"></i>
                                    <p class="text-secondary font-weight-medium m-0">8 mutaxassislik boʻyicha aspirantura</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About End -->


    <!-- Services Start -->
    
    <!-- Services End -->


    <!-- Features Start -->
    
    <!-- Features End -->


    <!-- Working Process Start -->
    
    <!-- Working Process End -->


    <!-- Pricing Plan Start -->
    
    <!-- Pricing Plan End -->


    <!-- Testimonial Start -->
    
    <!-- Testimonial End -->


    <!-- Blog Start -->
    <section class="news" id="news">
        <div class="container-fluid mt-5 pb-2">
            <div class="container">
                <h6 class="text-secondary text-uppercase text-center font-weight-medium mb-3">YANGILIKLAR   </h6>
                <h1 class="display-4 text-center mb-5">SO'NGI YANGILIKLAR</h1>
                <div class="row">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 mb-2">
                        <div class="shadow mb-4">
                            <div class="position-relative">
                                <img class="img-fluid w-100" src="<?php echo e($new->image); ?>" alt="" width="300">
                                <a href="<?php echo e(route('news.show', $new->id)); ?>" class="position-absolute w-100 h-100 d-flex flex-column align-items-center justify-content-center   text-decoration-none p-4" style="top: 0; left: 0; background: rgba(0, 0, 0, .4);">
                                </a>
                            </div>
                            <a href="<?php echo e(route('news.show', $new->id)); ?>">
                                <p class="m-0 p-4"><?php echo e($new->name); ?></p>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
                </div>
            </div>
        </div>
    </section>
    <!-- Blog End -->

    <!-- Footer Start -->
    <section class="contact" id="contact">
        <div class="container-fluid bg-primary text-white mt-5 pt-5 px-sm-3 px-md-5">
            <div class="row pt-5">
                <div class="col-lg-3 col-md-6 mb-5">
                    <h1 class="text-secondary mb-3"><span class="text-white">KAR</span>SU</h1>
                </div>
                <div class="col-lg-3 col-md-6 mb-5">
                    <a href="https://www.google.com/maps/dir//%D0%9A%D0%B0%D1%80%D0%B0%D0%BA%D0%B0%D0%BB%D0%BF%D0%B0%D0%BA%D1%81%D0%BA%D0%B8%D0%B9+%D0%B3%D0%BE%D1%81%D1%83%D0%B4%D0%B0%D1%80%D1%81%D1%82%D0%B2%D0%B5%D0%BD%D0%BD%D1%8B%D0%B9+%D1%83%D0%BD%D0%B8%D0%B2%D0%B5%D1%80%D1%81%D0%B8%D1%82%D0%B5%D1%82+%D0%B8%D0%BC%D0%B5%D0%BD%D0%B8+%D0%91%D0%B5%D1%80%D0%B4%D0%B0%D1%85%D0%B0+FJ3G%2B3QR+karsu_info@edu.uz,+A.+Dosnazarov+ko'shesi+Nukus/@42.4527436,59.626894,15z/data=!4m8!4m7!1m0!1m5!1m1!1s0x41dd9a73302110c9:0x91129d2b50e670e!2m2!1d59.626894!2d42.4527436"><img class="img-fluid w-100" src="images/karta.png" alt="" width="600"></a>
                </div>
                <div class="col-lg-3 col-md-6 mb-5">
                    <h4 class="text-white mb-4">Get In Touch</h4>
                    <p>Berdaq nomidagi Qoraqalpoq Davlat Universiteti</p>
                    <p><i class="fa fa-map-marker-alt mr-2"></i>O'zbekiston, Qoraqalpog'iston Respublikasi, Nukus shahri, Sh.Abdirov ko'chasi №1 uy</p>
                    <p><i class="fa fa-phone-alt mr-2"></i>Tel: +998612236078</p>
                    <p><i class="fa fa-envelope mr-2"></i>Email: karsu_info@edu.uz</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html><?php /**PATH C:\MAMP\htdocs\OTM\resources\views/index.blade.php ENDPATH**/ ?>