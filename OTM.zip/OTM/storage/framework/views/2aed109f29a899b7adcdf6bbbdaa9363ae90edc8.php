<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DRYME - Free Laundry Service Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset("lib/owlcarousel/assets/owl.carousel.min.css")); ?>" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset("css/style.css")); ?>" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
 

    <!-- Navbar Start -->
    <div class="container-fluid position-relative nav-bar p-0">
        <div class="container-lg position-relative p-0 px-lg-3" style="z-index: 9;">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0 pl-3 pl-lg-5">
                <a href="<?php echo e(url('')); ?>" class="navbar-brand">
                    <h1 class="m-0 text-secondary"><span class="text-primary">KAR</span>SU</h1>
                </a>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->


 

    <!-- About Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7 mt-5 mt-lg-0 pl-lg-5">
                    <h6 class="text-secondary text-uppercase font-weight-medium mb-3">YANGILIK HAQIDA</h6>
                    <h1 class="mb-4"><?php echo e($new->name); ?></h1>
                    <img class="img-fluid" src="<?php echo e(asset($new->image)); ?>" alt=""><br><br>
                    <p class="mb-2">
                    <?php echo e($new->description); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset("lib/easing/easing.min.js")); ?>"></script>
    <script src="<?php echo e(asset("lib/waypoints/waypoints.min.js")); ?>"></script>
    <script src="<?php echo e(asset("lib/counterup/counterup.min.js")); ?>"></script>
    <script src="<?php echo e(asset("lib/owlcarousel/owl.carousel.min.js")); ?>"></script>

    <!-- Contact Javascript File -->
    <script src="<?php echo e(asset("mail/jqBootstrapValidation.min.js")); ?>"></script>
    <script src="<?php echo e(asset("mail/contact.js")); ?>"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset("js/main.js")); ?>"></script>
</body>

</html><?php /**PATH C:\MAMP\htdocs\OTM\resources\views/show.blade.php ENDPATH**/ ?>