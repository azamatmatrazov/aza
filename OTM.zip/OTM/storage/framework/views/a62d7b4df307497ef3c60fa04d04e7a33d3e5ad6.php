<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MALUMOTLARNI O'ZGARTIRISH</title>
</head>
<body>
    <h2>MALUMOTLARNI O'ZGARTIRISH</h2>
    <h3><a href="<?php echo e(route('news.index')); ?>">BACK</a></h3><br>
    <form action="<?php echo e(route('news.update', $new->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="">Yangilikni o'zgarting: </label><br><br>
        <input type="text" name="name" value="<?php echo e($new->name); ?>"><br><br>
        <label for="">Yangilik haqida to'liq malumotni o'zgarting: </label><br><br>
        <input type="text" name="description" value="<?php echo e($new->description); ?>"><br><br>
        <label for="">Rasmni o'zgarting: </label><br><br>
        <input type="file" name="image"><br><br>
        <button>edit</button>
    </form>
</body>
</html><?php /**PATH C:\MAMP\htdocs\OTM\resources\views/admin/edit_news.blade.php ENDPATH**/ ?>