<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MALUMOTLAR DIZIMI</title>
</head>
<body>
    <h1>MALUMOTLAR DIZIMI</h1><br>
    <h2><li><a href="<?php echo e(route('news.create')); ?>">create</a></li></h2><br><br>
    <table border="5">
        <tr>
            <td>№</td>
            <td>Yangilik</td>
            <td>To'liq malumot</td>
            <td>Rasm</td>
            <td>O'zgartirish</td>
            <td>O'chirish</td>
        </tr>
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($new->name); ?></td>
            <td><?php echo e($new->description); ?></td>
            <td><img src="<?php echo e($new->image); ?>" alt="Rasm yo'q" width="200"></td>
            <td><a href="<?php echo e(route('news.edit', $new->id)); ?>">edit</a></td>
            <td>
                <form action="<?php echo e(route('news.destroy', $new->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button>delete</button>                    
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\MAMP\htdocs\OTM\resources\views/admin/news.blade.php ENDPATH**/ ?>