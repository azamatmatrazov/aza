<?php

namespace App\Http\Controllers;

use App\Models\News;
use App\Http\Requests\StoreNewsRequest;
use App\Http\Requests\UpdateNewsRequest;

class NewsController extends Controller
{
    public function index()
    {
        $news = News::get();
        return view('admin.news', ['news' => $news]);
    }

    public function create()
    {
        return view('admin.create_news');
    }

    public function store(StoreNewsRequest $request)
    {
        $imageName = time().'.'.$request->image->getClientOriginalExtension();
        $request->image->move(public_path('/images'), $imageName);
        News::create([
            'name' => $request->name,
            'description' => $request->description,
            'image' => 'images/'.$imageName
        ]);
        return redirect('news');
    }
   
    public function show($id)
    {
        $new = News::find($id);
        return view('show', ['new' => $new]);
    }

    public function edit($id)
    {
        $new = News::find($id);
        return view('admin.edit_news', ['new' => $new]);
    }

    public function update(UpdateNewsRequest $request, $id)
    {
        if(!isset($request->image))
        {
            $img_url = News::where('id', $id)->get()[0]['image'];
        }
        else
        {
            $imageName = time().'.'.$request->image->getClientOriginalExtension();
            $request->image->move(public_path('/images'), $imageName);
            $img_url = 'images/'.$imageName;
        }
        News::find($id)->update([
           'name' => $request->name,
           'description' => $request->description,
           'image' => $img_url 
        ]);
        return redirect('news');
    }

    public function destroy($id)
    {
        News::find($id)->destroy($id);
        return back();
    }
}
