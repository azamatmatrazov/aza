<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Http\Requests\StoreAdminRequest;
use App\Http\Requests\UpdateAdminRequest;
use App\Models\News;

class AdminController extends Controller
{
    public function index()
    {
        $news = News::get();
        $admin = Admin::get();
        if(count($admin) == 0)
        {
            Admin::create([
            'login' => 'diana2003',
            'password' => 'diana2003'
        ]);
        }
        return view('index', ['news' => $news]);
    }

    public function login(StoreAdminRequest $request)
    {
        $login = $request->login;
        $password = $request->password;
        $admin = Admin::get();
        foreach($admin as $ad)
        {
            if($ad['login'] == $login AND $ad['password'] == $password)
            {
                return view('admin.index');
            }
            else
            {
                return back();
            }
        }
    }
}    
