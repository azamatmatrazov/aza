<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\NewsController;
use Illuminate\Support\Facades\Route;



Route::get('/', [AdminController::class, 'index']);
Route::get('/admin', function(){
    return view('login');
});
Route::post('/login', [AdminController::class, 'login']);
Route::resource('news', NewsController::class);
