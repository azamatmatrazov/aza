<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MALUMOTLAR DIZIMI</title>
</head>
<body>
    <h1>MALUMOTLAR DIZIMI</h1><br>
    <h2><li><a href="{{ route('news.create') }}">create</a></li></h2><br><br>
    <table border="5">
        <tr>
            <td>№</td>
            <td>Yangilik</td>
            <td>To'liq malumot</td>
            <td>Rasm</td>
            <td>O'zgartirish</td>
            <td>O'chirish</td>
        </tr>
        @foreach ($news as $new)
        <tr>
            <td>{{ $loop->iteration }}</td>
            <td>{{ $new->name }}</td>
            <td>{{ $new->description }}</td>
            <td><img src="{{ $new->image }}" alt="Rasm yo'q" width="200"></td>
            <td><a href="{{ route('news.edit', $new->id) }}">edit</a></td>
            <td>
                <form action="{{ route('news.destroy', $new->id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button>delete</button>                    
                </form>
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>