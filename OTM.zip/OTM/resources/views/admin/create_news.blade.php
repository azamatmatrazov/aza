<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MALUMOTLARNI QO'SHISH</title>
</head>
<body>
    <h2>MALUMOTLARNI QO'SHISH</h2>
    <h3><a href="{{ route('news.index') }}">BACK</a></h3><br>
    <form action="{{ route('news.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <label for="">Yangilikni kiriting: </label><br><br>
        <input type="text" name="name" required><br><br>
        <label for="">Yangilik haqida to'liq malumotni kiriting: </label><br><br>
        <input type="text" name="description" required><br><br>
        <label for="">Rasmni kiriting: </label><br><br>
        <input type="file" name="image" required><br><br>
        <button>create</button>
    </form>
</body>
</html>